'use strict';
/*
 * One place for "may the agent do this?" decisions.
 *
 *  - Risky controls and key combos ALWAYS ask the user, even in auto-approve mode. The user can only ADD
 *    words to the list (agent.alwaysAsk); nothing here can be turned off by a setting.
 *  - Shells, installers and admin tools are never launched by name (open_app).
 *  - Optional app rules from Settings: a blocklist (never touch these windows) or an allowlist (only these).
 */

// Delete, Send, Pay, Install, Sign out, closing things, plus the usual "cannot be undone" verbs.
// Stems with endings, so "Delete", "Deleting" and "Deleted" all count.
const RISKY_NAME = new RegExp('\\b(' + [
  'delet(e|es|ed|ing)', 'remov(e|es|ed|ing|al)', 'eras(e|es|ed|ing)', 'format (this |the )?(disk|drive|volume|usb|partition)',
  'uninstall(s|ed|ing)?', 'install(s|ed|ing|er)?', 'empty (the )?recycle', 'recycle bin', 'trash',
  'send(s|ing)?', 'submit(s|ted|ting)?', 'post(s|ing)?', 'publish(es|ed|ing)?',
  'pay(s|ing|ment|ments)?', 'buy(s|ing)?', 'purchas(e|es|ed|ing)', 'check ?out', 'place order', 'confirm order',
  'transfer(s|red|ring)?', 'withdraw(s|n|ing|al)?',
  'sign[\\s-]?(out|off)', 'log[\\s-]?(out|off)', 'shut ?down', 'restart(s|ing)?', 'reset(s|ting)?',
  'clear (all|history|data)', 'discard(s|ed|ing)?', 'overwrit(e|es|ing)',
  'clos(e|es|ing)', 'exit(s|ing)?', 'quit(s|ting)?', 'terminat(e|es|ing)', 'end task', 'force quit',
].join('|') + ')\\b', 'i');

const ALIAS = {
  control: 'ctrl', lctrl: 'ctrl', rctrl: 'ctrl', return: 'enter', windows: 'win', super: 'win', meta: 'win', cmd: 'win',
  lwin: 'win', rwin: 'win', menu: 'alt', lalt: 'alt', ralt: 'alt', lshift: 'shift', rshift: 'shift', del: 'delete', esc: 'escape',
};

function comboSets(keys) {
  return String(keys || '')
    .toLowerCase()
    .split(/\s*(?:,|\bthen\b|\s)\s*/)
    .filter(Boolean)
    .map((combo) => new Set(combo.split('+').map((k) => k.trim()).filter(Boolean).map((k) => ALIAS[k] || k)));
}

function isRiskyCombo(set) {
  const has = (k) => set.has(k);
  if (has('delete')) return true; // Delete, Shift+Delete, Ctrl+Alt+Delete ...
  if (has('alt') && has('f4')) return true; // close window / quit app
  if (has('ctrl') && (has('w') || has('f4'))) return true; // close tab / window
  if (has('ctrl') && has('shift') && (has('w') || has('q'))) return true;
  if (has('ctrl') && has('enter')) return true; // "send" in mail and chat apps
  if (has('win') && has('l')) return true; // lock
  return false;
}

function isRiskyName(name, extraWords = []) {
  const n = String(name || '');
  if (RISKY_NAME.test(n)) return true;
  const lower = n.toLowerCase();
  return (extraWords || []).some((w) => w && lower.includes(String(w).toLowerCase()));
}

function isRiskyKeys(keys) {
  return comboSets(keys).some(isRiskyCombo);
}

// Programs the agent must not start by name, whatever the user says: shells, scripting hosts, installers, admin tools.
const BLOCKED_LAUNCH = new Set([
  'cmd', 'powershell', 'pwsh', 'powershell_ise', 'wt', 'windowsterminal', 'terminal', 'windows terminal', 'command prompt',
  'conhost', 'bash', 'wsl', 'regedit', 'reg', 'mshta',
  'wscript', 'cscript', 'msiexec', 'diskpart', 'bcdedit', 'taskkill', 'shutdown', 'schtasks', 'netsh', 'sc', 'net', 'mmc',
  'gpedit', 'secpol', 'eventvwr', 'rundll32', 'regsvr32', 'certutil', 'bitsadmin', 'winget', 'choco', 'scoop',
]);

function isBlockedLaunch(name) {
  const base = String(name || '').trim().toLowerCase().replace(/\.(exe|com|bat|cmd|msc|ps1)$/, '');
  if (BLOCKED_LAUNCH.has(base)) return true;
  return /(^|[\s_-])(setup|installer|install)([\s_-]|$)/.test(base);
}

// --- app rules chosen in Settings -> Agent ("what may it touch") ---
const DEFAULT_BLOCKED_APPS = ['1password', 'bitwarden', 'keepass', 'lastpass', 'dashlane', 'windows security', 'credential manager', 'registry editor'];

function norm(s) {
  return String(s || '').toLowerCase();
}

// info = { title, app }. Returns { allowed, reason }
function checkAccess(rules, info) {
  const r = rules || {};
  const hay = norm((info && info.title) || '') + ' | ' + norm((info && info.app) || '');
  const hit = (list) => (list || []).map(norm).filter(Boolean).find((w) => hay.includes(w));
  const blocked = hit(r.blockedApps);
  if (blocked) return { allowed: false, reason: `You blocked "${blocked}" in the access rules, so I will not touch it.` };
  if (r.accessMode === 'allowlist') {
    const known = (info && (info.title || info.app));
    if (!known) return { allowed: false, reason: 'Allowlist mode is on and I cannot tell which app is in front, so I will not act.' };
    if (!hit(r.allowedApps)) return { allowed: false, reason: `Allowlist mode is on and "${(info.app || info.title).slice(0, 40)}" is not on your allowed list.` };
  }
  return { allowed: true, reason: '' };
}

module.exports = { RISKY_NAME, isRiskyName, isRiskyKeys, comboSets, isBlockedLaunch, BLOCKED_LAUNCH, DEFAULT_BLOCKED_APPS, checkAccess };
